// ===================================================
// LOWCAT BOT · BOT.JS
// ===================================================
// ID do bot: 1482401730099544104
// Token incluído diretamente (não recomendado para produção pública)
// ===================================================

// Importações principais
import { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } from 'discord.js';
import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import chalk from 'chalk';
import moment from 'moment';
import { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, getVoiceConnection } from '@discordjs/voice';
import play from 'play-dl';

// ----------------------
// CONFIGURAÇÃO BÁSICA
// ----------------------
const TOKEN = "8d9fddc5a732e89cba84aad836cc93079f4f9675017a0e1a7026fc8838754456"; // Seu token direto
const PREFIX = "!"; // Prefixo padrão
const CLIENT_ID = "1482401730099544104"; // ID do bot

// Cria o client do Discord
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});

// ----------------------
// BANCO DE DADOS JSON
// ----------------------
const DATABASE_PATH = './database.json';
let db = {};

function loadDatabase() {
  if (!fs.existsSync(DATABASE_PATH)) {
    fs.writeFileSync(DATABASE_PATH, JSON.stringify({
      config: {
        prefix: PREFIX,
        botStatus: "online",
        botActivity: "LowCat Bot · Gerencie seu servidor",
        embedColor: "#8B5CF6",
        defaultLanguage: "pt-BR"
      },
      servers: {},
      users: {},
      economy: { shop: [] },
      music: { queues: {}, settings: { volume: 50, autoplay: false, filters: [] } },
      logs: { modActions: [], ticketActions: [] },
      defaultServerStructure: {}
    }, null, 2));
  }
  db = JSON.parse(fs.readFileSync(DATABASE_PATH, 'utf-8'));
  console.log(chalk.green('[DB] Database carregado com sucesso.'));
}

function saveDatabase() {
  fs.writeFileSync(DATABASE_PATH, JSON.stringify(db, null, 2));
  console.log(chalk.yellow('[DB] Database salvo.'));
}

// ----------------------
// COMANDOS
// ----------------------
client.commands = new Collection();
client.slashCommands = new Collection();

// Carrega comandos de pasta /commands
function loadCommands() {
  const commandsPath = path.join('./Comandos.js'); // No seu caso, todos os comandos estão em Comandos.js
  if (fs.existsSync(commandsPath)) {
    const commands = JSON.parse(fs.readFileSync(commandsPath, 'utf-8'));
    for (const cmd of commands) {
      client.commands.set(cmd.name.toLowerCase(), cmd);
      client.slashCommands.set(cmd.name.toLowerCase(), cmd); // Para slash commands também
    }
    console.log(chalk.blue(`[CMD] ${commands.length} comandos carregados.`));
  } else {
    console.log(chalk.red('[CMD] Arquivo Comandos.js não encontrado!'));
  }
}

// ----------------------
// EVENTOS
// ----------------------
client.on('ready', () => {
  console.log(chalk.green(`\n[READY] ${client.user.tag} está online!`));
  client.user.setActivity(db.config.botActivity || "LowCat Bot", { type: 3 }); // Tipo 3 = Watching
});

// Mensagens prefixadas
client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;
  const server = message.guild.id;

  if (!db.servers[server]) {
    db.servers[server] = JSON.parse(JSON.stringify(db.defaultServerStructure));
    saveDatabase();
  }

  if (!message.content.startsWith(PREFIX)) return;
  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command = client.commands.get(commandName);
  if (!command) return;

  try {
    await command.run({ client, message, args, db, saveDatabase });
  } catch (error) {
    console.error(chalk.red(`[ERROR] Comando ${commandName} falhou:`), error);
    message.reply({ content: '❌ Ocorreu um erro ao executar esse comando.' });
  }
});

// Interações slash commands e botões
client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    const command = client.slashCommands.get(interaction.commandName.toLowerCase());
    if (!command) return;
    try {
      await command.run({ client, interaction, db, saveDatabase });
    } catch (error) {
      console.error(chalk.red(`[ERROR] SlashCommand ${interaction.commandName} falhou:`), error);
      interaction.reply({ content: '❌ Ocorreu um erro ao executar esse comando.', ephemeral: true });
    }
  }

  if (interaction.isButton()) {
    // Aqui você pode tratar os botões do painel web ou comandos interativos
  }
});

// ----------------------
// LOGIN
// ----------------------
loadDatabase();
loadCommands();
client.login(TOKEN);